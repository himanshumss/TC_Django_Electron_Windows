from django.db import models
from datetime import datetime

class Class(models.Model):
    createclass = models.CharField(max_length=50)
    classid = models.IntegerField(default=1)
    def __str__(self):
        return self.createclass
    

class sessionyear(models.Model):
    year = models.CharField(max_length=100)
    def __str__(self):
        return self.year


class university(models.Model):
    universityname = models.CharField(max_length=200)
    def __str__(self):
        return self.universityname

# Create your models here.
class Students(models.Model):
    srn = models.CharField(default=None, max_length=100)
    enrollment = models.CharField(default=None, max_length=100)
    rollno = models.CharField(default=None, max_length=100)
    uname = models.CharField(max_length=500, default="Maa Shakumbri Unversity, Saharanppur")
    studentname = models.CharField(max_length=100)
    fathersname = models.CharField(max_length=100)
    mothersname = models.CharField(max_length=100)
    address = models.CharField(max_length=500)
    dob = models.CharField(max_length=100)
    doa = models.CharField(max_length=100)
    dues = models.CharField(max_length=100)
    ldate = models.CharField(max_length=100)
    studtinclass = models.CharField(max_length=100)
    sessyear = models.CharField(max_length=100)
    issuedate = models.DateField()
    def __str__(self):
        return self.studentname

    

class alreadygenerated(models.Model):
    alreadygeneratedid = models.IntegerField(default=1)
    enroll = models.CharField(max_length=100)
    def __str__(self):
        return self.enroll