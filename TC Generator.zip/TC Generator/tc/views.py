from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from tc.models import Students, Class, sessionyear, university

# Create your views here.
def home(request):
    return render(request, "home.html")


def createclass(request):
    classlist = Class.objects.all()
    context = {
        "classlist" : classlist
    }
    if request.method == "POST":
        clsname = request.POST.get("class_name")
        data = Class(
            classid = Class.objects.count() + 1,
            createclass = clsname
        )
        data.save()
        return redirect("classcreate")
    return render(request, "createclass.html", context)


def createsession(request):
    sessionlist = sessionyear.objects.all()
    context = {
        "sessionlist" : sessionlist
    }
    if request.method == "POST":
        ssnname = request.POST.get("session_name")
        data = sessionyear(
            year = ssnname
        )
        data.save()
        return redirect("sessioncreate")
    return render(request, "createsession.html", context)

def createuniversity(request):
    universitylist = university.objects.all()
    context = {
        "universitylist" : universitylist
    }
    if request.method == "POST":
        uniname = request.POST.get("University_name")
        data = university(
           
            universityname = uniname
        )
        data.save()
        return redirect("universitycreate")
    return render(request, "createuniversity.html", context)



def addstudent(request):
    classlist = Class.objects.all()
    sessions = sessionyear.objects.all()
    context = {
        "classlist" : classlist,
        "sessions" : sessions
    }
    if request.method == "POST":
        srnumber = request.POST.get("srNo")
        enrollno = request.POST.get("enrollmentNo")
        rollno = request.POST.get("rollNo")
        studentname = request.POST.get("studentName")
        fname = request.POST.get("fathersName")
        mname = request.POST.get("mothersName")
        add = request.POST.get("address")
        birth = request.POST.get("dob")
        admi = request.POST.get("doa")
        dues = request.POST.get("duesClearDate")
        leaving = request.POST.get("dol")
        classpass = request.POST.get("classPassed")
        session = request.POST.get("session")
        isudate = date.today()
        data = Students(
            srn = srnumber,
            enrollment = enrollno,
            rollno = rollno,
            studentname  =studentname,
            fathersname = fname,
            mothersname = mname,
            address = add,
            dob = birth,
            doa = admi,
            dues = dues,
            ldate = leaving,
            studtinclass = classpass,
            sessyear = session,
            issuedate = isudate
        )
        data.save()
        return redirect("addstudent")
    return render(request, "addstudent.html", context)

from django.shortcuts import render, redirect
from tc.models import alreadygenerated, Students
from datetime import date

def generatetc(request):
    student_info = None  # To store student details if found

    if request.method == "POST":
        enr = request.POST.get("enrollmentInput")

        # Check if the enrollment number exists in the alreadygenerated table
        if alreadygenerated.objects.filter(enroll=enr).exists():
            print("Already generated")
            student_info = Students.objects.filter(enrollment=enr).first()  # Fetch student details
            print(student_info)
            context = {
                "message" : " TC Already generated"
            }
            if not student_info:
                print("Student record not found")
            
        else:
            print("Not generated")
            student_info = Students.objects.filter(enrollment=enr).first()
            data = alreadygenerated(
                alreadygeneratedid = alreadygenerated.objects.count() + 1,
                enroll = enr
            )
            data.save()
            today = date.today()
            return render(request, "generatetc.html", {"student_info": student_info, 'today': today})  # Redirect if TC is not generated

        # Pass student_info to the template if found
        return render(request, "generatetc.html", {"student_info": student_info})

    return render(request, "generatetc.html")

