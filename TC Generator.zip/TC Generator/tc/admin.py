from django.contrib import admin
from tc.models import Class, Students, sessionyear, university, alreadygenerated
# Register your models here.
admin.site.register(Class)
admin.site.register(Students)
admin.site.register(sessionyear)
admin.site.register(university)
admin.site.register(alreadygenerated)
