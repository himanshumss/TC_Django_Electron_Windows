const {app, BrowserWindow} = require('electron');
function ElectronMainMethod(){
    const launchWindow = new BrowserWindow({
        title : "SDCMS",
        width : 800,
        height : 600
    });
    const appURL = "http://localhost:8000";
    launchWindow.loadURL(appURL);
}//endmain
app.whenReady().then(ElectronMainMethod);