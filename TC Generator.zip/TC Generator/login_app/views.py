from django.shortcuts import render, redirect

# Create your views here.
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required


def loginpage(request):
    if request.method == "POST":
        user1 = request.POST.get("username")
        pass1 = request.POST.get("password")
        user = authenticate(request, username = user1, password = pass1)
        if user is not None:
            login(request, user)
            return redirect("home")
        return render(request, "login.html")
    return render(request, "login.html")
    

@login_required(login_url="login")
def logoutpage(request):
    logout(request)
    return redirect("login")